USE classicmodels_json;
SELECT 
    JSON_EXTRACT(employee_data, '$.employeeNumber') AS employee_id,
    JSON_UNQUOTE(JSON_EXTRACT(employee_data, '$.lastName')) AS apellido
FROM employees;