USE classicmodels_xml;
SELECT ExtractValue(xml_data, '//employee[@employeeNumber="1166"]/office/City') AS ciutat_oficina_1166
FROM employees_xml;