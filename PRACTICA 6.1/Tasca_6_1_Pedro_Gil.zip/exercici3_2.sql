USE classicmodels_xml;
SELECT ExtractValue(xml_data, '//employee[jobTitle="VP Sales"]/email') AS emails_vp_sales
FROM employees_xml;