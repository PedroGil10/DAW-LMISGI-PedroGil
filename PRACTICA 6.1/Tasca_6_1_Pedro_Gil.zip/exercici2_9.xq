let $nl := "&#10;"
let $numEmpleats := count(collection("CLASSICMODELS_BD")//employee)
let $numClients := count(collection("CLASSICMODELS_BD")//customer)
let $numXecs := count(collection("CLASSICMODELS_BD")//check)
return concat(
  "Número d'empleats: ", $numEmpleats, $nl,
  "Número de clients: ", $numClients, $nl,
  "Número de xecs: ", $numXecs
)