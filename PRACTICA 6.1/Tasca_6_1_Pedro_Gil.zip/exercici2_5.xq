let $mitjana := avg(doc("Payments.xml")//check/amount)
for $check in doc("Payments.xml")//check
where $check/amount > $mitjana
order by $check/@number
return $check/@number