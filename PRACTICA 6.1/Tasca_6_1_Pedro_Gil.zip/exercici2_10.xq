for $employee in doc("Employees.xml")//employee
where $employee/lastName = "Patterson"
return $employee/@employeeNumber