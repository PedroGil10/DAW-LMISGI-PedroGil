let $mitjana := 32432
for $check in collection("CLASSICMODELS_BD")//check
where $check/amount > $mitjana
order by number($check/amount) descending
return concat("Compte: ", $check/@number, ", Import: ", $check/amount, ", Client: ", $check/customer/customerName)