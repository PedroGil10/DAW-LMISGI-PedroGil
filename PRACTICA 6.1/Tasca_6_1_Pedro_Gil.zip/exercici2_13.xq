let $customerNumbers := (103, 112)
for $check in doc("Payments.xml")//check
where $check/customer/@customerNumber = $customerNumbers
return $check/@number