CREATE DATABASE IF NOT EXISTS classicmodels_xml;
USE classicmodels_xml;

CREATE TABLE employees_xml (
    id INT AUTO_INCREMENT PRIMARY KEY,
    xml_data TEXT
);