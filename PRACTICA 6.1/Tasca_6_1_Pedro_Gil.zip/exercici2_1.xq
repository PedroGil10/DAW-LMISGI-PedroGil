for $customer in doc("Customers.xml")//customer
let $credit := number($customer/creditLimit)
where $credit >= 1160 
  and $credit <= 1165
return $customer/customerName/text()