USE classicmodels_xml;
SELECT ExtractValue(xml_data, '//employee[reportsTo="1056"]/lastName') AS cognoms_empleats_1056
FROM employees_xml;