let $customer := doc("Customers.xml")//customer[customerName = "Atelier graphique"]
let $customerNumber := $customer/@customerNumber
for $check in doc("Payments.xml")//check
where $check/customer/@customerNumber = $customerNumber
return $check/@number