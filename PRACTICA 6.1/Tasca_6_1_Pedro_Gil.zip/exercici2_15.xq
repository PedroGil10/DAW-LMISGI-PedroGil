for $check in doc("Payments.xml")//check
let $salesRepNumber := $check/customer/salesRepEmployeeNumber
let $employee := doc("Employees.xml")//employee[@employeeNumber = $salesRepNumber]
where $employee/lastName = "Fixter" or $employee/lastName = "King"
order by number($check/amount) descending
return concat("ID: ", $check/@number, ", Quantitat: ", $check/amount)