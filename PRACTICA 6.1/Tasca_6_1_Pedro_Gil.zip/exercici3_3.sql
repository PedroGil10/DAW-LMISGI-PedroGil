USE classicmodels_xml;
SELECT ExtractValue(xml_data, 'count(//employee[office/Territory="EMEA"])') AS empleados_emea
FROM employees_xml;
