for $check in doc("Payments.xml")//check
where $check/customer/customerName = doc("Customers.xml")//customer[contact/contactLastName = "King" or contact/contactLastName = "Schmitt"]/customerName
order by number($check/amount) descending
return $check/amount