USE classicmodels_json;
SELECT JSON_UNQUOTE(JSON_EXTRACT(office_data, '$.phone')) AS telefono
FROM offices;