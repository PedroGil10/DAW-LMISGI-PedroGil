USE classicmodels_json;
SELECT * FROM offices LIMIT 3;
SELECT * FROM employees LIMIT 3;