sum(
  for $check in doc("Payments.xml")//check
  where $check/customer/salesRepEmployeeNumber = 1370
  return number($check/amount)
)