for $employee in doc("Employees.xml")//employee
let $nom := concat($employee/firstName, " ", $employee/lastName)
let $numero := $employee/@employeeNumber
let $ciutat := $employee/office/City
order by number($numero)
return concat("Nom:", $nom, ", Numero d'empleat:", $numero, ", Oficina assignada:", $ciutat)