USE classicmodels_json;
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(e.employee_data, '$.employeeNumber')) AS numero_empleado,
    CONCAT(
        JSON_UNQUOTE(JSON_EXTRACT(e.employee_data, '$.firstName')), 
        ' ', 
        JSON_UNQUOTE(JSON_EXTRACT(e.employee_data, '$.lastName'))
    ) AS nombre_completo,
    JSON_UNQUOTE(JSON_EXTRACT(o.office_data, '$.city')) AS ciudad_oficina
FROM employees e
JOIN offices o 
    ON JSON_EXTRACT(e.employee_data, '$.officeCode') = JSON_EXTRACT(o.office_data, '$.officeCode');
