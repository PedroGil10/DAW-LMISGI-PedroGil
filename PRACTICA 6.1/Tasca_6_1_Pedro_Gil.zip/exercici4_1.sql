CREATE DATABASE IF NOT EXISTS classicmodels_json;
USE classicmodels_json;

CREATE TABLE offices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    office_data JSON
);

CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_data JSON
);