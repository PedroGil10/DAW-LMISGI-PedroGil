for $check in doc("Payments.xml")//check
where $check/customer/@customerNumber = 103
return $check/@number