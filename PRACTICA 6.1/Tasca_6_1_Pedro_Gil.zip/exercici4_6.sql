USE classicmodels_json;
SELECT employee_data
FROM employees
WHERE JSON_EXTRACT(employee_data, '$.extension') LIKE '%23%';
