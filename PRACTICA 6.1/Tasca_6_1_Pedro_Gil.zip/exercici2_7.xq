round(
  avg(
    for $check in collection("CLASSICMODELS_BD")//check
    return number($check/amount)
  )
)