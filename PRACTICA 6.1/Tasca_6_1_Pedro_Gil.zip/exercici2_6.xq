count(
  for $employee in collection("CLASSICMODELS_BD")//employee
  return $employee
)